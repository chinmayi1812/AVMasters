import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ViewVideoService {

  constructor(private http: HttpClient) { }

  public getAllVideo(): Observable<any> {
    return this.http.get("https://avmasters.azurewebsites.net/api/Asset") as Observable<any>;
  }
}
