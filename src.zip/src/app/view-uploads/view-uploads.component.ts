import { Component, OnInit } from '@angular/core';
import { ViewVideoService } from './view-video.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-uploads',
  templateUrl: './view-uploads.component.html',
  styleUrls: ['./view-uploads.component.css']
})
export class ViewUploadsComponent implements OnInit {
  list: any;
  
  constructor(private vidService: ViewVideoService, private route: Router) { }

  ngOnInit(): void {
    this.vidService.getAllVideo().subscribe((success) => {
      this.list = success;
    }, (error) => { })

  }
  openVideo(assetId) {
    console.log(assetId)
    this.route.navigate(['/video', { id: assetId }])
  }

}
