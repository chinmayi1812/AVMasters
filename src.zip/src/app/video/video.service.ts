import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class VideoService {

  constructor(private http: HttpClient) { }

  getVideoByAssetId(id): Observable<any> {
    return this.http.get("https://avmasters.azurewebsites.net/api/Asset/" + id) as Observable<any>
  }
}
