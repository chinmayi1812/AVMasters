import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UploadVideoComponent } from './upload-video/upload-video.component';
import { ViewUploadsComponent } from './view-uploads/view-uploads.component';
import { VideoComponent } from './video/video.component';


const routes: Routes = [
  { path: "upload", component: UploadVideoComponent },
  { path: "view", component: ViewUploadsComponent },
  { path: "video", component: VideoComponent },
  { path: "video/:id", component: VideoComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
